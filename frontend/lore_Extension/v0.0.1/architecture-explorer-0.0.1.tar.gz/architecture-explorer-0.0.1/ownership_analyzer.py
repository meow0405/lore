from collections import defaultdict

def analyze_ownership(commits: list[dict]) -> dict:
    file_authors = defaultdict(lambda: defaultdict(int))
    
    for c in commits:
        author = c["author"]
        for f in c["files"]:
            file_authors[f["name"]][author] += 1
            
    result = {}
    for name, authors in file_authors.items():
        total_commits = sum(authors.values())
        sorted_authors = sorted(authors.items(), key=lambda x: x[1], reverse=True)
        
        primary_author = sorted_authors[0][0]
        primary_commits = sorted_authors[0][1]
        secondary_author = sorted_authors[1][0] if len(sorted_authors) > 1 else None
        
        concentration = primary_commits / total_commits if total_commits > 0 else 0
        bus_factor = 1 if concentration > 0.8 else len(sorted_authors)
        
        result[name] = {
            "primary_author": primary_author,
            "secondary_author": secondary_author,
            "author_concentration": round(concentration, 2),
            "bus_factor": bus_factor,
            "total_authors": len(sorted_authors)
        }
        
    return {"ownership": result}
