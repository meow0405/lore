import os

def validate_source(root_dir: str) -> dict:
    validation = {
        "confirmed": [],
        "uncertain": [],
        "contradictions": []
    }
    
    src_dir = os.path.join(root_dir, "src")
    if os.path.isdir(src_dir):
        top_dirs = [d for d in os.listdir(src_dir) if os.path.isdir(os.path.join(src_dir, d))]
        validation["confirmed"].append(f"Found source directories: {', '.join(top_dirs)}")
    else:
        top_dirs = [d for d in os.listdir(root_dir) if os.path.isdir(os.path.join(root_dir, d)) and not d.startswith('.') and d not in ('node_modules', 'venv', '__pycache__')]
        validation["confirmed"].append(f"Found root directories: {', '.join(top_dirs)}")
        
    return {"validation": validation}
