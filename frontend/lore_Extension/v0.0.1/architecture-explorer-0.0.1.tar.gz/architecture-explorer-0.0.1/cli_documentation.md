# CLI Documentation: Understanding Context and Git History

This guide explains how the command-line tool works to gather your project's context and Git history in simple terms.

## What Does the CLI Do?

The CLI (Command Line Interface) is designed to scan a repository, look at its history, and understand its architecture and risk areas. You run it using a simple command:

```bash
python main.py <path_to_repo>
```

When you run this command, the tool goes through several steps to understand your code:

### 1. Mining the Repository (Git History)
The tool starts by looking at your Git history. It fetches the most recent commits to understand what has changed over time. For each commit, it records:
- **Who** made the change.
- **When** the change was made.
- **What** files were modified.
- **How many** lines were added or deleted.

### 2. Analyzing the Code
After gathering the history, the tool runs several analyzers to make sense of the data:
- **Commit Analysis**: Looks at how frequently files change.
- **Ownership Analysis**: Determines which developers "own" or work most on specific parts of the code.
- **Temporal Analysis**: Understands when changes happen over time.
- **Dependency Graph**: Figures out how different files and components rely on each other.

### 3. Calculating Risks (Heatmap)
Using the information gathered above, the tool generates a "Heatmap". This heatmap assigns a risk score to each file based on its complexity, how often it changes, and how many other files depend on it.

### 4. Detecting Subsystems and Milestones
The tool also identifies major subsystems (groups of related files) and significant milestones (major updates) in the project's history.

### 5. Generating Architecture with AI
Finally, the tool gathers all this context and sends it to an AI model. The AI generates a comprehensive architectural overview, identifies risk clusters, and provides recommendations.

### The Final Output
The tool saves all its findings into a file called `architecture.json`. This file acts as the brain for the VS Code extension, providing it with all the context and risk scores it needs to visualize your project.
