import re

def find_milestones(commits: list[dict]) -> dict:
    milestones = []
    
    keywords = ["architecture", "refactor", "migration", "rewrite", "extract", 
                "modularize", "service", "repository", "event", "queue", "cache", "api", "gateway"]
    
    pattern = re.compile(r'\b(?:' + '|'.join(keywords) + r')\b', re.IGNORECASE)
    
    for c in commits:
        msg = c["message"]
        matches = pattern.findall(msg)
        if matches:
            files_changed = c["stats"]["files_changed"]
            if files_changed > 5:
                milestones.append({
                    "date": c["date"],
                    "title": msg.split('\n')[0],
                    "evidence": [f"Commit {c['sha']} changed {files_changed} files", f"Keywords matched: {', '.join(set(matches))}"],
                    "confidence": 80
                })
                
    return {"milestones": milestones}
