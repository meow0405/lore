from datetime import datetime, timezone
from collections import defaultdict

def analyze_temporal(commits: list[dict]) -> dict:
    file_dates = defaultdict(list)
    
    for c in commits:
        try:
            date_str = c["date"]
            if date_str.endswith('Z'):
                date_str = date_str[:-1] + '+00:00'
            dt = datetime.fromisoformat(date_str)
            for f in c["files"]:
                file_dates[f["name"]].append(dt)
        except Exception:
            pass
            
    now = datetime.now(timezone.utc)
    
    result = {}
    for name, dates in file_dates.items():
        dates.sort()
        change_frequency = len(dates)
        
        if change_frequency > 1:
            total_days = (dates[-1] - dates[0]).days
            churn_rate = change_frequency / (total_days + 1)
        else:
            churn_rate = 0
            
        months_since_last = (now - dates[-1]).days / 30.0
        
        result[name] = {
            "change_frequency": change_frequency,
            "churn_rate": round(churn_rate, 4),
            "months_since_last_change": round(months_since_last, 1)
        }
        
    return {"temporal": result}
