from collections import deque, defaultdict
import os

def get_subsystem(filepath: str) -> str:
    parts = filepath.split('/')
    if len(parts) > 1:
        if parts[0] == "src" and len(parts) > 2:
            return f"{parts[0]}/{parts[1]}"
        return parts[0]
    return "root"

def generate_heatmap(deps: dict, commits: dict, ownership: dict, temporal: dict) -> dict:
    edges = deps.get("dependency_graph", {}).get("edges", [])
    nodes = deps.get("dependency_graph", {}).get("nodes", [])
    
    affected_by = defaultdict(list)
    in_degree = defaultdict(int)
    
    for edge in edges:
        u = edge["from"]
        v = edge["to"]
        if not v.endswith(".py"):
            v += ".py"
        affected_by[v].append(u)
        in_degree[v] += 1
        
    all_files = set(commits.get("file_metrics", {}).keys())
    for n in nodes:
        all_files.add(n)
        
    heatmap = {}
    hotspots = []
    impact_predictions = []
    
    CRITICAL_DOMAINS = ["auth", "billing", "payment", "permission", "order", "identity"]
    MEDIUM_DOMAINS = ["report", "notification"]
    
    for f in all_files:
        direct_deps = set(affected_by[f])
        visited = set(direct_deps)
        queue = deque(direct_deps)
        while queue:
            curr = queue.popleft()
            for nxt in affected_by[curr]:
                if nxt not in visited:
                    visited.add(nxt)
                    queue.append(nxt)
        
        indirect_deps = visited - direct_deps
        
        affected_subsystems = set()
        for dep in visited:
            affected_subsystems.add(get_subsystem(dep))
            
        blast_direct = len(direct_deps)
        blast_indirect = len(indirect_deps)
        blast_subs = len(affected_subsystems)
        
        blast_score = min((blast_direct * 5) + (blast_indirect * 2) + (blast_subs * 10), 100)
        
        coupling_score = min(in_degree[f] * 5, 100)
        
        f_temp = temporal.get("temporal", {}).get(f, {})
        f_commits = commits.get("file_metrics", {}).get(f, {})
        churn_freq = f_commits.get("touch_frequency", 0)
        churn_vel = f_temp.get("churn_rate", 0)
        churn_score = min((churn_freq * 2) + (churn_vel * 10), 100)
        
        age_months = f_temp.get("months_since_last_change", 0)
        legacy_score = min(age_months * 5, 100)
        if churn_score > 50 and legacy_score > 50:
            legacy_score = min(legacy_score * 1.5, 100)
        if coupling_score > 50 and legacy_score > 50:
            legacy_score = min(legacy_score * 1.5, 100)
            
        f_own = ownership.get("ownership", {}).get(f, {})
        bus_factor = f_own.get("bus_factor", 1)
        author_concentration = f_own.get("author_concentration", 0)
        if bus_factor == 1:
            ownership_score = min(author_concentration * 100, 100)
        else:
            ownership_score = max(100 - (bus_factor * 10), 0)
            
        domain_score = 10
        f_lower = f.lower()
        if any(c in f_lower for c in CRITICAL_DOMAINS):
            domain_score = 100
        elif any(c in f_lower for c in MEDIUM_DOMAINS):
            domain_score = 50
            
        if blast_subs > 3:
            coupling_score = min(coupling_score + 20, 100)
            
        risk_score = (
            (0.30 * blast_score) +
            (0.20 * coupling_score) +
            (0.15 * churn_score) +
            (0.15 * legacy_score) +
            (0.10 * ownership_score) +
            (0.10 * domain_score)
        )
        
        if risk_score <= 30: risk_level = "Safe"
        elif risk_score <= 60: risk_level = "Moderate"
        elif risk_score <= 80: risk_level = "High"
        else: risk_level = "Critical"
        
        reasons = []
        if blast_score > 60: reasons.append(f"{len(visited)} dependent files across {blast_subs} subsystems")
        if coupling_score > 60: reasons.append(f"High incoming coupling ({in_degree[f]} references)")
        if churn_score > 60: reasons.append(f"{churn_freq} historical modifications")
        if legacy_score > 60: reasons.append(f"High legacy weight (inactive for {age_months} months)")
        if ownership_score > 60: reasons.append(f"High ownership risk (concentration {int(author_concentration*100)}%)")
        if domain_score == 100: reasons.append("Core critical subsystem")
        if blast_subs > 3: reasons.append("Architectural choke point")
        
        heatmap[f] = {
            "file": f,
            "riskScore": round(risk_score, 1),
            "riskLevel": risk_level,
            "reasons": reasons,
            "confidence": 90
        }
        
        impact_predictions.append({
            "file": f,
            "impact": {
                "directFiles": list(direct_deps)[:10],
                "indirectFiles": list(indirect_deps)[:10],
                "subsystems": list(affected_subsystems),
                "estimatedRisk": round(risk_score, 1)
            }
        })
        
        if churn_score > 70 and blast_score > 70 and coupling_score > 70:
            hotspots.append({
                "file": f,
                "hotspot": True,
                "severity": "critical",
                "riskScore": round(risk_score, 1)
            })

    return {
        "heatmap": heatmap,
        "hotspots": hotspots,
        "impactPredictions": impact_predictions
    }
