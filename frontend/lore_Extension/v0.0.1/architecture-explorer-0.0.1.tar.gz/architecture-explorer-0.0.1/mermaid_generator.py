import json
import os
import sys
import urllib.request


def generate_mermaid(architecture_data: dict, diagram_type: str) -> str:
    if diagram_type == "architecture":
        instructions = """
        You are a Mermaid JS generator.
        Generate a `flowchart TD` Mermaid diagram representing the architecture of the system.
        Use the subsystems, dependencies, and architectural smells to map nodes and edges.
        OUTPUT ONLY THE MERMAID CODE. NO MARKDOWN FORMATTING (do not wrap in ```mermaid).
        """
    else:
        instructions = """
        You are a Mermaid JS generator.
        Generate a `timeline` Mermaid diagram representing the chronological milestones of the system.
        Use the milestones array from the provided data.
        CRITICAL RULE: DO NOT use colons (":") inside the time strings or event descriptions. Colons break Mermaid timeline syntax. Replace any colons in times or text with dashes ("-").
        OUTPUT ONLY THE MERMAID CODE. NO MARKDOWN FORMATTING (do not wrap in ```mermaid).
        """

    model = os.getenv("OLLAMA_MODEL", "minimax-m3:cloud")

    prompt = f"JSON Architecture Data:\\n\\n{json.dumps(architecture_data, indent=2)}"

    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": instructions},
            {"role": "user", "content": prompt},
        ],
        "stream": False,
    }

    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        "http://localhost:11434/api/chat",
        data=data,
        headers={"Content-Type": "application/json"},
    )

    try:
        with urllib.request.urlopen(req) as response:
            result = json.loads(response.read().decode("utf-8"))
            content = result["message"]["content"]
            content = content.replace("```mermaid", "").replace("```", "").strip()
            return content
    except Exception as e:
        raise Exception(f"Ollama API Error: {e}")


def main():
    if len(sys.argv) < 2:
        print("Usage: python mermaid_generator.py <path_to_architecture_json>")
        sys.exit(1)

    json_path = sys.argv[1]
    with open(json_path, "r") as f:
        content = f.read().strip()
        # Clean potential markdown formatting
        if content.startswith("```json"):
            content = content[7:]
        if content.startswith("```"):
            content = content[3:]
        if content.endswith("```"):
            content = content[:-3]
        content = content.strip()
        
        try:
            arch_data = json.loads(content)
        except json.JSONDecodeError:
            print("Error: Input file must be valid JSON.")
            sys.exit(1)

    print("Generating Architecture Graph (flowchart)...")
    arch_mmd = generate_mermaid(arch_data, "architecture")
    with open("architecture.mmd", "w") as f:
        f.write(arch_mmd)
    print("Saved to architecture.mmd")

    print("Generating Evolution Timeline...")
    time_mmd = generate_mermaid(arch_data, "timeline")
    with open("timeline.mmd", "w") as f:
        f.write(time_mmd)
    print("Saved to timeline.mmd")


if __name__ == "__main__":
    main()
