import os
import ast

def build_dependency_graph(repo_path: str) -> dict:
    nodes = []
    edges = []
    
    for root, _, files in os.walk(repo_path):
        if "venv" in root or "__pycache__" in root or ".git" in root:
            continue
        for f in files:
            if f.endswith(".py"):
                path = os.path.relpath(os.path.join(root, f), repo_path)
                nodes.append(path)
                
                try:
                    with open(os.path.join(root, f), 'r') as pyfile:
                        content = pyfile.read()
                    tree = ast.parse(content)
                    for node in ast.walk(tree):
                        if isinstance(node, ast.Import):
                            for alias in node.names:
                                edges.append({"from": path, "to": alias.name})
                        elif isinstance(node, ast.ImportFrom):
                            if node.module:
                                edges.append({"from": path, "to": node.module})
                except Exception:
                    pass
                    
    return {"dependency_graph": {"nodes": nodes, "edges": edges}}
