import sys
import json
import os
from git_miner import mine_repository
from subsystem_detector import detect_subsystems
from milestone_finder import find_milestones
from source_validator import validate_source
from llm_generator import generate_architecture

from commit_analyzer import analyze_commits
from ownership_analyzer import analyze_ownership
from temporal_analyzer import analyze_temporal
from dependency_graph import build_dependency_graph
from heatmap_engine import generate_heatmap

def main():
    if len(sys.argv) < 2:
        print("Usage: python main.py <path_to_repo>")
        sys.exit(1)
        
    repo_path = sys.argv[1]
    
    if not os.path.exists(repo_path):
        print(f"Error: Path {repo_path} does not exist.")
        sys.exit(1)
        
    os.chdir(repo_path)
    
    print("Mining repository...", file=sys.stderr)
    repo_data = mine_repository()
    commits = repo_data["commits"]
    
    print("Running intelligence analyzers...", file=sys.stderr)
    commit_metrics = analyze_commits(commits)
    ownership_metrics = analyze_ownership(commits)
    temporal_metrics = analyze_temporal(commits)
    dep_graph = build_dependency_graph(repo_path)
    heatmap_data = generate_heatmap(dep_graph, commit_metrics, ownership_metrics, temporal_metrics)
    
    print("Detecting subsystems...", file=sys.stderr)
    subsystems_data = detect_subsystems(commits)
    
    print("Finding milestones...", file=sys.stderr)
    milestones_data = find_milestones(commits)
    
    print("Validating source...", file=sys.stderr)
    validation_data = validate_source(repo_path)
    
    combined_data = {
        "repository": repo_data,
        "commit_metrics": commit_metrics,
        "ownership_metrics": ownership_metrics,
        "temporal_metrics": temporal_metrics,
        "dependency_graph": dep_graph,
        "heatmap": heatmap_data["heatmap"],
        "subsystems": subsystems_data,
        "milestones": milestones_data,
        "source_validation": validation_data
    }
    
    print("Generating architecture with LLM...", file=sys.stderr)
    try:
        llm_output = generate_architecture(combined_data)
        llm_json = json.loads(llm_output)
    except Exception as e:
        print(f"LLM Error: {e}", file=sys.stderr)
        llm_json = {
            "architecture": {},
            "riskClusters": [],
            "recommendations": []
        }
        
    final_output = {
        "architecture": llm_json.get("architecture", {}),
        "heatmap": heatmap_data.get("heatmap", {}),
        "hotspots": heatmap_data.get("hotspots", []),
        "impactPredictions": heatmap_data.get("impactPredictions", []),
        "riskClusters": llm_json.get("riskClusters", []),
        "recommendations": llm_json.get("recommendations", [])
    }
    
    try:
        with open("architecture.json", "w") as f:
            json.dump(final_output, f, indent=2)
        print("Successfully generated architecture model and saved to architecture.json", file=sys.stderr)
        print(json.dumps(final_output, indent=2))
    except Exception as e:
        print(f"Output Error: {e}", file=sys.stderr)

if __name__ == "__main__":
    main()
