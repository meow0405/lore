import json
import os
import urllib.error
import urllib.request


def generate_architecture(prompt_data: dict) -> str:
    system_instruction = """
    You are an Architecture Discovery Agent.
    Your goal is to recover the architecture of a software system from Git history and deterministic metrics.
    No guessing. Every pattern must include evidence. DO NOT hallucinate subsystem boundaries.
    DO NOT generate Mermaid, C4 diagrams, or React Flow nodes.
    
    You must output ONLY valid JSON. 
    
    JSON Schema to follow:
    {
      "architecture": {
        "subsystems": [{"name": "Subsystem name", "confidence": 80, "evidence": ["evidence"]}],
        "patterns": [{"name": "Layered", "confidence": 85, "evidence": ["evidence"]}],
        "layers": [{"name": "API", "confidence": 90, "evidence": ["evidence"]}]
      },
      "riskClusters": [{"name": "Cluster name", "description": "Desc"}],
      "recommendations": [{"action": "Action", "target": "File or Module", "reason": "Reason"}]
    }
    """

    model = os.getenv("OLLAMA_MODEL", "minimax-m3:cloud")

    prompt = f"Analyze the following repository evolution data and output the architecture model:\\n\\n{json.dumps(prompt_data, indent=2)[:80000]}"

    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_instruction},
            {"role": "user", "content": prompt},
        ],
        "format": "json",
        "stream": False,
    }

    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        "http://localhost:11434/api/chat",
        data=data,
        headers={"Content-Type": "application/json"},
    )

    try:
        with urllib.request.urlopen(req) as response:
            result = json.loads(response.read().decode("utf-8"))
            content = result["message"]["content"]
            
            # Clean potential markdown formatting
            content = content.strip()
            if content.startswith("```json"):
                content = content[7:]
            if content.startswith("```"):
                content = content[3:]
            if content.endswith("```"):
                content = content[:-3]
                
            return content.strip()
    except Exception as e:
        raise Exception(f"Ollama API Error: {e}")
