import os
from collections import defaultdict
import subprocess

def run_cmd(cmd: list[str]) -> str:
    try:
        return subprocess.check_output(cmd, encoding='utf-8', stderr=subprocess.DEVNULL)
    except Exception:
        return ""

def detect_subsystems(commits: list[dict]) -> dict:
    subsystems = []
    
    dirs = defaultdict(int)
    for c in commits:
        for f in c["files"]:
            fname = f["name"]
            parts = fname.split('/')
            if len(parts) > 1:
                if parts[0] == "src" and len(parts) > 2:
                    d = f"{parts[0]}/{parts[1]}"
                else:
                    d = parts[0]
                dirs[d] += 1
                
    for d, count in dirs.items():
        if count > 5:
            subsystems.append({
                "name": d,
                "confidence": 60,
                "evidence": [f"Directory {d} has {count} historical changes."]
            })
            
    shortlog = run_cmd(["git", "shortlog", "-sn", "--all"])
    contributors = []
    for line in shortlog.strip().split('\n'):
        if line:
            parts = line.strip().split('\t', 1)
            if len(parts) == 2:
                contributors.append(parts[1])
                
    return {"subsystems": subsystems, "major_contributors": contributors[:10]}
