import subprocess
import json

def run_cmd(cmd: list[str]) -> str:
    try:
        return subprocess.check_output(cmd, encoding='utf-8', stderr=subprocess.DEVNULL)
    except Exception:
        return ""

def mine_repository() -> dict:
    log_format = "%H|%aI|%aN|%s"
    log_output = run_cmd(["git", "log", "-n", "5", f"--format={log_format}"])
    
    commits = []
    if not log_output:
        return {"commits": [], "timeline": []}
        
    lines = [line for line in log_output.strip().split('\n') if line]
    for line in reversed(lines):
        parts = line.split('|', 3)
        if len(parts) == 4:
            commits.append({
                "sha": parts[0],
                "date": parts[1],
                "author": parts[2],
                "message": parts[3],
                "stats": {"insertions": 0, "deletions": 0, "files_changed": 0},
                "files": []
            })
            
    stat_output = run_cmd(["git", "log", "-n", "5", "--numstat", "--format=%H"])
    current_sha = None
    commit_map = {c["sha"]: c for c in commits}
    
    for line in stat_output.strip().split('\n'):
        line = line.strip()
        if not line: continue
        if len(line) == 40 and '\t' not in line:
            current_sha = line
        else:
            if current_sha and current_sha in commit_map:
                parts = line.split('\t')
                if len(parts) == 3:
                    ins, dels, fname = parts
                    try:
                        ins_val = int(ins) if ins != '-' else 0
                        del_val = int(dels) if dels != '-' else 0
                        c = commit_map[current_sha]
                        c["stats"]["insertions"] += ins_val
                        c["stats"]["deletions"] += del_val
                        c["stats"]["files_changed"] += 1
                        c["files"].append({
                            "name": fname,
                            "insertions": ins_val,
                            "deletions": del_val
                        })
                    except ValueError:
                        pass
    
    return {"commits": commits, "timeline": [c["sha"] for c in commits]}

if __name__ == "__main__":
    print(json.dumps(mine_repository(), indent=2))
