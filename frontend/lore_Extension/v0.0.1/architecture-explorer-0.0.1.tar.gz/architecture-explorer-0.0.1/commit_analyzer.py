from collections import defaultdict

def analyze_commits(commits: list[dict]) -> dict:
    file_stats = defaultdict(lambda: {
        "touch_frequency": 0,
        "insertions": 0,
        "deletions": 0,
        "co_changed_files": defaultdict(int)
    })
    
    for c in commits:
        files = c["files"]
        file_names = [f["name"] for f in files]
        
        for f in files:
            name = f["name"]
            stats = file_stats[name]
            stats["touch_frequency"] += 1
            stats["insertions"] += f.get("insertions", 0)
            stats["deletions"] += f.get("deletions", 0)
            
            for other_file in file_names:
                if other_file != name:
                    stats["co_changed_files"][other_file] += 1

    # Convert defaultdicts to dicts, keep top 10 co-changed
    result = {}
    for name, stats in file_stats.items():
        top_co_changed = sorted(stats["co_changed_files"].items(), key=lambda x: x[1], reverse=True)[:10]
        result[name] = {
            "touch_frequency": stats["touch_frequency"],
            "insertions": stats["insertions"],
            "deletions": stats["deletions"],
            "co_changed_files": [f[0] for f in top_co_changed]
        }
        
    return {"file_metrics": result}
