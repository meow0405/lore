flowchart TD
Main["Orchestration / Entry Point<br/>(main.py)"]
GitMiner["Git Mining Layer<br/>(git_miner.py)"]
SourceValidator["Source Validation Subsystem<br/>(source_validator.py)"]
MilestoneFinder["Milestone Analysis Subsystem<br/>(milestone_finder.py)"]
SubsystemDetector["Subsystem Detection Subsystem<br/>(subsystem_detector.py)"]
LLMGen["LLM Generation Subsystem<br/>(llm_generator.py)"]
MermaidGen["Diagram Generation Subsystem<br/>(mermaid_generator.py)"]
Output["Output / Serialization<br/>(architecture.json)"]

    GitLib["Git Library<br/>(GitPython / PyDriller)"]
    LLMExt["External LLM Provider<br/>(OpenAI / Anthropic SDK)"]

    subgraph Pipeline
        Main
        GitMiner
        SourceValidator
        MilestoneFinder
        SubsystemDetector
        LLMGen
        MermaidGen
        Output
    end

    subgraph External
        GitLib
        LLMExt
    end

    Main -->|orchestrates| GitMiner
    Main -->|orchestrates| SourceValidator
    Main -->|orchestrates| MilestoneFinder
    Main -->|orchestrates| SubsystemDetector
    Main -->|orchestrates| LLMGen
    Main -->|orchestrates| MermaidGen
    Main -->|emits| Output

    GitMiner -->|raw commit records<br/>(sha, date, author, message, stats, files)| SourceValidator
    GitMiner -->|uses| GitLib

    SourceValidator -->|validated evidence| MilestoneFinder
    SourceValidator -->|validated evidence| SubsystemDetector
    SourceValidator -->|gates pipeline| Output

    MilestoneFinder -->|milestones.json data| LLMGen
    SubsystemDetector -->|subsystems.json data| LLMGen

    LLMGen -->|enriched descriptions| Output
    LLMGen -->|calls| LLMExt

    MermaidGen -->|Mermaid diagrams| Output

    subgraph Architectural_Smells
        direction TB
        PyCache["Committed __pycache__/*.pyc<br/>(build artifacts in VCS)"]
        BulkCommit["Bulk/Shotgun Commit<br/>(13 files, 280 insertions)"]
        NoTests["Missing Tests<br/>(no test_*.py)"]
        SingleAuthor["Single-Author Bus-Factor Risk<br/>(100% SaptanshuWanjari)"]
        TightCoupling["Implicit Coupling<br/>(main.py direct imports)"]
        UnvalidatedLLM["Unvalidated LLM Output<br/>(no schema enforcement)"]
    end

    PyCache -.->|smell| GitMiner
    BulkCommit -.->|smell| Main
    NoTests -.->|smell| Output
    SingleAuthor -.->|smell| Main
    TightCoupling -.->|smell| Main
    UnvalidatedLLM -.->|smell| LLMGen
