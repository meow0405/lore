import * as vscode from 'vscode';
import * as path from 'path';
import * as fs from 'fs';
import * as cp from 'child_process';
export function activate(context: vscode.ExtensionContext) {
  context.subscriptions.push(
    vscode.commands.registerCommand('architecture-explorer.showGraph', () => {
      ArchitectureExplorerPanel.createOrShow(context.extensionUri);
    })
  );

  // File Decoration Provider for Risk Indicators
  const decorationProvider = new ArchitectureDecorationProvider();
  context.subscriptions.push(
    vscode.window.registerFileDecorationProvider(decorationProvider)
  );
}

class ArchitectureExplorerPanel {
  public static currentPanel: ArchitectureExplorerPanel | undefined;
  public static readonly viewType = 'architecture-explorer';
  private readonly _panel: vscode.WebviewPanel;
  private readonly _extensionUri: vscode.Uri;
  private _disposables: vscode.Disposable[] = [];

  public static createOrShow(extensionUri: vscode.Uri) {
    const column = vscode.window.activeTextEditor ? vscode.window.activeTextEditor.viewColumn : undefined;

    if (ArchitectureExplorerPanel.currentPanel) {
      ArchitectureExplorerPanel.currentPanel._panel.reveal(column);
      return;
    }

    const panel = vscode.window.createWebviewPanel(
      ArchitectureExplorerPanel.viewType,
      'Architecture Explorer',
      column || vscode.ViewColumn.One,
      {
        enableScripts: true,
        localResourceRoots: [
          extensionUri,
          ...(vscode.workspace.workspaceFolders ? vscode.workspace.workspaceFolders.map(f => f.uri) : [])
        ]
      }
    );

    ArchitectureExplorerPanel.currentPanel = new ArchitectureExplorerPanel(panel, extensionUri);
  }

  private constructor(panel: vscode.WebviewPanel, extensionUri: vscode.Uri) {
    this._panel = panel;
    this._extensionUri = extensionUri;

    this._panel.webview.html = this._getHtmlForWebview(this._panel.webview);

    this._panel.onDidDispose(() => this.dispose(), null, this._disposables);

    this._panel.webview.onDidReceiveMessage(data => {
      switch (data.type) {
        case 'openFile':
          {
            const filePath = data.path;
            const workspaceFolders = vscode.workspace.workspaceFolders;
            if (workspaceFolders) {
              const fullPath = path.join(workspaceFolders[0].uri.fsPath, filePath);
              vscode.workspace.openTextDocument(fullPath).then(doc => {
                vscode.window.showTextDocument(doc);
              });
            }
          }
          break;
        case 'requestData':
          {
            this._sendArchitectureData();
          }
          break;
        case 'runAnalysis':
          {
            this._runAnalysis();
          }
          break;
      }
    }, null, this._disposables);

    this._sendArchitectureData();

    vscode.window.onDidChangeActiveTextEditor(editor => {
        if (editor && this._panel) {
            const fileName = path.basename(editor.document.fileName);
            this._panel.webview.postMessage({ type: 'activeFileChanged', file: fileName });
        }
    }, null, this._disposables);
  }

  public dispose() {
    ArchitectureExplorerPanel.currentPanel = undefined;
    this._panel.dispose();
    while (this._disposables.length) {
      const x = this._disposables.pop();
      if (x) {
        x.dispose();
      }
    }
  }

  private _sendArchitectureData() {
    const workspaceFolders = vscode.workspace.workspaceFolders;
    if (workspaceFolders) {
        const workspacePath = workspaceFolders[0].uri.fsPath;
        const jsonPath = path.join(workspacePath, 'architecture.json');
        const mmdPath = path.join(workspacePath, 'architecture.mmd');
        
        if (fs.existsSync(jsonPath)) {
            const jsonUri = this._panel.webview.asWebviewUri(vscode.Uri.file(jsonPath)).toString();
            const mmdUri = fs.existsSync(mmdPath) ? this._panel.webview.asWebviewUri(vscode.Uri.file(mmdPath)).toString() : undefined;
            
            this._panel.webview.postMessage({ 
                type: 'architectureDataUri', 
                jsonUri, 
                mmdUri 
            });
        } else {
            vscode.window.showErrorMessage("Architecture Explorer: architecture.json not found in workspace.");
        }
    }
  }

  private _runAnalysis() {
    const workspaceFolders = vscode.workspace.workspaceFolders;
    if (!workspaceFolders) {
      this._panel.webview.postMessage({ type: 'analysisLog', message: 'Error: No workspace open.' });
      this._panel.webview.postMessage({ type: 'analysisCompleted' });
      return;
    }

    const workspacePath = workspaceFolders[0].uri.fsPath;
    const scriptPath = path.join(this._extensionUri.fsPath, '..', 'main.py');
    
    this._panel.webview.postMessage({ type: 'analysisLog', message: `Starting analysis in ${workspacePath}...` });
    this._panel.webview.postMessage({ type: 'analysisLog', message: `Executing: python ${scriptPath} ${workspacePath}` });

    const process = cp.spawn('python', [scriptPath, workspacePath]);

    process.stdout.on('data', (data) => {
      this._panel.webview.postMessage({ type: 'analysisLog', message: data.toString() });
    });

    process.stderr.on('data', (data) => {
      this._panel.webview.postMessage({ type: 'analysisLog', message: data.toString() });
    });

    process.on('close', (code) => {
      this._panel.webview.postMessage({ type: 'analysisLog', message: `Analysis finished with exit code ${code}` });
      this._panel.webview.postMessage({ type: 'analysisCompleted' });
      // Automatically refresh data after run
      if (code === 0) {
        this._sendArchitectureData();
      }
    });

    process.on('error', (err) => {
      this._panel.webview.postMessage({ type: 'analysisLog', message: `Failed to start subprocess: ${err.message}` });
      this._panel.webview.postMessage({ type: 'analysisCompleted' });
    });
  }

  private _getHtmlForWebview(webview: vscode.Webview) {
    const scriptUri = webview.asWebviewUri(vscode.Uri.joinPath(this._extensionUri, 'webview-ui', 'dist', 'assets', 'index.js'));
    const styleUri = webview.asWebviewUri(vscode.Uri.joinPath(this._extensionUri, 'webview-ui', 'dist', 'assets', 'index.css'));
    return `<!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src ${webview.cspSource} 'unsafe-inline'; script-src ${webview.cspSource} 'unsafe-inline' 'unsafe-eval'; connect-src ${webview.cspSource}; font-src ${webview.cspSource};">
        <title>Architecture Explorer</title>
        <script type="module" src="${scriptUri}"></script>
        <link rel="stylesheet" href="${styleUri}">
      </head>
      <body>
        <div id="root"></div>
      </body>
      </html>`;
  }
}

class ArchitectureDecorationProvider implements vscode.FileDecorationProvider {
    private _onDidChangeFileDecorations: vscode.EventEmitter<vscode.Uri | vscode.Uri[]> = new vscode.EventEmitter<vscode.Uri | vscode.Uri[]>();
    readonly onDidChangeFileDecorations: vscode.Event<vscode.Uri | vscode.Uri[]> = this._onDidChangeFileDecorations.event;

    private heatmap: any = {};

    constructor() {
        this.loadHeatmap();
    }

    private loadHeatmap() {
        const workspaceFolders = vscode.workspace.workspaceFolders;
        if (workspaceFolders) {
            const jsonPath = path.join(workspaceFolders[0].uri.fsPath, 'architecture.json');
            if (fs.existsSync(jsonPath)) {
                try {
                    const data = fs.readFileSync(jsonPath, 'utf8');
                    const parsed = JSON.parse(data);
                    if (parsed.heatmap) {
                        this.heatmap = parsed.heatmap;
                    }
                } catch (e) {
                    console.error("Failed to parse architecture.json", e);
                }
            }
        }
    }

    provideFileDecoration(uri: vscode.Uri, token: vscode.CancellationToken): vscode.ProviderResult<vscode.FileDecoration> {
        const fileName = path.basename(uri.fsPath);
        const score = this.heatmap[fileName];
        
        if (score !== undefined) {
            if (score > 80) {
                return new vscode.FileDecoration("🔴", "Critical Risk");
            } else if (score > 60) {
                return new vscode.FileDecoration("🟠", "High Risk");
            } else if (score > 30) {
                return new vscode.FileDecoration("🟡", "Medium Risk");
            } else {
                return new vscode.FileDecoration("🟢", "Safe");
            }
        }
        return undefined;
    }
}
