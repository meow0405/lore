import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface AppState {
  data: any | null;
  selectedNodeId: string | null;
  searchQuery: string;
  riskThreshold: number;
  expandedSubsystems: string[];
  isAnalyzing: boolean;
  logs: string[];
  
  setData: (data: any) => void;
  setSelectedNodeId: (id: string | null) => void;
  setSearchQuery: (query: string) => void;
  setRiskThreshold: (threshold: number) => void;
  toggleSubsystem: (subsystem: string) => void;
  setIsAnalyzing: (isAnalyzing: boolean) => void;
  addLog: (log: string) => void;
  clearLogs: () => void;
}

export const useStore = create<AppState>()(
  persist(
    (set) => ({
      data: null,
      selectedNodeId: null,
      searchQuery: '',
      riskThreshold: 0,
      expandedSubsystems: [],
      isAnalyzing: false,
      logs: [],

      setData: (data) => set({ data }),
      setSelectedNodeId: (selectedNodeId) => set({ selectedNodeId }),
      setSearchQuery: (searchQuery) => set({ searchQuery }),
      setRiskThreshold: (riskThreshold) => set({ riskThreshold }),
      toggleSubsystem: (sub) =>
        set((state) => ({
          expandedSubsystems: state.expandedSubsystems.includes(sub)
            ? state.expandedSubsystems.filter((s) => s !== sub)
            : [...state.expandedSubsystems, sub],
        })),
      setIsAnalyzing: (isAnalyzing) => set({ isAnalyzing }),
      addLog: (log) => set((state) => ({ logs: [...state.logs, log] })),
      clearLogs: () => set({ logs: [] }),
    }),
    {
      name: 'architecture-explorer-storage',
      partialize: (state) => ({
        selectedNodeId: state.selectedNodeId,
        searchQuery: state.searchQuery,
        riskThreshold: state.riskThreshold,
        expandedSubsystems: state.expandedSubsystems,
      }),
    }
  )
);
