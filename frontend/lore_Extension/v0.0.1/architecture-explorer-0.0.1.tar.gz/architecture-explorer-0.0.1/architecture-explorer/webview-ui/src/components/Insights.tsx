import React from 'react';
import { useStore } from '../store';
import { AlertCircle, Lightbulb, ShieldAlert } from 'lucide-react';

const Insights: React.FC = () => {
  const data = useStore(state => state.data);

  if (!data) return null;

  const recommendations = data.recommendations || [];
  const riskClusters = data.riskClusters || [];

  return (
    <div className="p-4 bg-panel h-full flex flex-col">
      <h2 className="text-lg font-bold mb-4 border-b border-border pb-2 flex items-center gap-2">
        <Lightbulb className="w-5 h-5 text-yellow-500" />
        Architecture Insights
      </h2>
      <div className="flex-1 overflow-y-auto space-y-4 pr-2">
        {recommendations.length > 0 && (
          <div className="space-y-2">
            <h3 className="text-sm font-semibold text-gray-400 uppercase">Recommendations</h3>
            {recommendations.map((rec: any, idx: number) => (
              <div key={idx} className="bg-blue-500/10 border border-blue-500/20 p-3 rounded flex gap-3 text-sm">
                <AlertCircle className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                <div>
                  {typeof rec === 'string' ? (
                    <span>{rec}</span>
                  ) : (
                    <>
                      <div className="font-bold mb-1">{rec.action}</div>
                      <div className="text-gray-400 text-xs"><span className="font-semibold text-gray-300">Target:</span> {rec.target}</div>
                      <div className="text-gray-400 text-xs mt-1"><span className="font-semibold text-gray-300">Reason:</span> {rec.reason}</div>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {riskClusters.length > 0 && (
          <div className="space-y-2">
            <h3 className="text-sm font-semibold text-gray-400 uppercase mt-4">Risk Clusters</h3>
            {riskClusters.map((cluster: any, idx: number) => (
              <div key={idx} className="bg-red-500/10 border border-red-500/20 p-3 rounded text-sm">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold flex items-center gap-2">
                    <ShieldAlert className="w-4 h-4 text-red-400" />
                    {cluster.name || `Cluster ${idx+1}`}
                  </span>
                  <span className="text-red-400 font-bold">{cluster.riskScore}</span>
                </div>
                <div className="text-gray-400 text-xs">
                  {cluster.files?.length || 0} files affected
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Insights;
