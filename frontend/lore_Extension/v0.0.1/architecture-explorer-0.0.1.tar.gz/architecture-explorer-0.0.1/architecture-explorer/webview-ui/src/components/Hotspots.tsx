import React, { useMemo } from 'react';
import { useStore } from '../store';
import { openFile } from '../vscode';

const Hotspots: React.FC = () => {
  const data = useStore(state => state.data);
  const setSelectedNodeId = useStore(state => state.setSelectedNodeId);

  const hotspots = useMemo(() => {
    if (!data?.heatmap) return [];
    
    return Object.entries(data.heatmap)
      .map(([file, info]: [string, any]) => ({ file, score: info.riskScore || 0 }))
      .sort((a, b) => b.score - a.score)
      .slice(0, 10);
  }, [data]);

  const handleFileClick = (file: string) => {
    openFile(file);
    setSelectedNodeId(file);
  };

  if (!data) return null;

  return (
    <div className="p-4 bg-panel h-full flex flex-col">
      <h2 className="text-lg font-bold mb-4 border-b border-border pb-2">Top Hotspots</h2>
      <div className="flex-1 overflow-y-auto">
        <table className="w-full text-sm text-left">
          <thead className="text-xs text-gray-400 uppercase bg-gray-800">
            <tr>
              <th className="px-4 py-2">File</th>
              <th className="px-4 py-2 text-right">Risk Score</th>
            </tr>
          </thead>
          <tbody>
            {hotspots.map((h, idx) => (
              <tr 
                key={idx} 
                className="border-b border-border hover:bg-gray-800 cursor-pointer transition-colors"
                onClick={() => handleFileClick(h.file)}
              >
                <td className="px-4 py-2 font-medium break-all">{h.file}</td>
                <td className="px-4 py-2 text-right">
                  <span className={`px-2 py-1 rounded text-xs font-bold ${
                    h.score > 80 ? 'bg-red-500/20 text-red-500' :
                    h.score > 60 ? 'bg-orange-500/20 text-orange-500' :
                    h.score > 30 ? 'bg-yellow-500/20 text-yellow-500' :
                    'bg-green-500/20 text-green-500'
                  }`}>
                    {h.score}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Hotspots;
