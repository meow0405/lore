import React, { useMemo } from 'react';
import { useStore } from '../store';

const RiskSummary: React.FC = () => {
  const data = useStore(state => state.data);

  const stats = useMemo(() => {
    if (!data?.heatmap) return { critical: 0, high: 0, medium: 0, safe: 0, total: 0 };
    let critical = 0, high = 0, medium = 0, safe = 0;
    
    Object.values(data.heatmap).forEach((item: any) => {
      const score = item.riskScore || 0;
      if (score > 80) critical++;
      else if (score > 60) high++;
      else if (score > 30) medium++;
      else safe++;
    });

    const total = critical + high + medium + safe;
    return { critical, high, medium, safe, total };
  }, [data]);

  if (stats.total === 0) return null;

  return (
    <div className="h-full flex items-center px-4 w-full justify-between bg-panel">
      <div className="flex gap-6 font-medium text-sm">
        <div className="text-red-500">Critical: {stats.critical}</div>
        <div className="text-orange-500">High: {stats.high}</div>
        <div className="text-yellow-500">Medium: {stats.medium}</div>
        <div className="text-green-500">Safe: {stats.safe}</div>
      </div>
      
      <div className="flex-1 max-w-xl mx-8 flex h-3 rounded overflow-hidden bg-gray-800">
        <div className="bg-red-500" style={{ width: `${(stats.critical/stats.total)*100}%` }} title="Critical" />
        <div className="bg-orange-500" style={{ width: `${(stats.high/stats.total)*100}%` }} title="High" />
        <div className="bg-yellow-500" style={{ width: `${(stats.medium/stats.total)*100}%` }} title="Medium" />
        <div className="bg-green-500" style={{ width: `${(stats.safe/stats.total)*100}%` }} title="Safe" />
      </div>

      <div className="text-xs text-gray-400">Total: {stats.total} Files</div>
    </div>
  );
};

export default RiskSummary;
