import React, { useEffect, useRef, useMemo } from 'react';
import mermaid from 'mermaid';
import { useStore } from '../store';
import { TransformWrapper, TransformComponent } from 'react-zoom-pan-pinch';

const Graph: React.FC = () => {
  const data = useStore(state => state.data);
  const graphRef = useRef<HTMLDivElement>(null);

  const graphString = useMemo(() => {
    if (data?.mmd) return data.mmd;
    if (!data || !data.heatmap) return '';
    let str = 'graph TD\n';
    
    const files = Object.keys(data.heatmap);
    files.forEach(file => {
      const score = data.heatmap[file]?.riskScore || 0;
      const label = file.split('/').pop() || file;
      const id = file.replace(/[^a-zA-Z0-9]/g, '_');
      str += `  ${id}["${label}<br/>Risk: ${score}"]\n`;
      
      let color = '#16a34a'; // green
      if (score > 80) color = '#dc2626'; // red
      else if (score > 60) color = '#ea580c'; // orange
      else if (score > 30) color = '#ca8a04'; // yellow
      
      str += `  style ${id} fill:${color},color:#fff,stroke:#fff,stroke-width:2px\n`;
    });

    if (data.impactPredictions) {
      data.impactPredictions.forEach((pred: any) => {
        if (pred.impact?.directFiles) {
          const sourceId = pred.file.replace(/[^a-zA-Z0-9]/g, '_');
          pred.impact.directFiles.forEach((target: string) => {
            if (files.includes(target)) {
              const targetId = target.replace(/[^a-zA-Z0-9]/g, '_');
              str += `  ${sourceId} --> ${targetId}\n`;
            }
          });
        }
      });
    }

    return str;
  }, [data]);

  useEffect(() => {
    mermaid.initialize({
      startOnLoad: false,
      theme: 'dark',
      securityLevel: 'loose',
      maxTextSize: 1000000,
    });
    // @ts-ignore
    mermaid.mermaidAPI.updateSiteConfig({ maxEdges: 100000 });
  }, []);

  useEffect(() => {
    if (graphRef.current && graphString) {
      graphRef.current.innerHTML = '';
      mermaid.render('mermaid-graph', graphString).then((result) => {
        if (graphRef.current) {
          graphRef.current.innerHTML = result.svg;
        }
      }).catch(err => {
        console.error('Mermaid render error', err);
      });
    }
  }, [graphString]);

  return (
    <div className="w-full h-full bg-[#1e1e1e] flex items-center justify-center overflow-hidden">
      {graphString ? (
        <TransformWrapper initialScale={1} minScale={0.1} maxScale={10} centerOnInit={true}>
          <TransformComponent wrapperStyle={{ width: "100%", height: "100%" }}>
            <div ref={graphRef} className="mermaid" />
          </TransformComponent>
        </TransformWrapper>
      ) : (
        <div className="text-gray-500">No architecture data available.</div>
      )}
    </div>
  );
};

export default Graph;
