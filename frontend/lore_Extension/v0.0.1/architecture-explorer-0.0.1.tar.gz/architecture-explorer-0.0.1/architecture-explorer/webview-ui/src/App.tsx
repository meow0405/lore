import React, { useEffect, useState } from 'react';
import { useStore } from './store';
import { requestData, vscode } from './vscode';
import Graph from './components/Graph';
import RiskSummary from './components/RiskSummary';
import Hotspots from './components/Hotspots';
import Insights from './components/Insights';
import AnalysisRunner from './components/AnalysisRunner';

function App() {
  const setData = useStore((state) => state.setData);
  const data = useStore((state) => state.data);
  const addLog = useStore((state) => state.addLog);
  const setIsAnalyzing = useStore((state) => state.setIsAnalyzing);

  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      const message = event.data;
      switch (message.type) {
        case 'architectureDataUri':
          Promise.all([
            fetch(message.jsonUri).then(r => r.json()),
            message.mmdUri ? fetch(message.mmdUri).then(r => r.text()) : Promise.resolve(null)
          ]).then(([parsedJson, mmdText]) => {
            if (mmdText) {
              parsedJson.mmd = mmdText;
            }
            setData(parsedJson);
          }).catch(err => {
            console.error("Failed to fetch architecture data", err);
          });
          break;
        case 'architectureData':
          setData(message.data);
          break;
        case 'activeFileChanged':
          // Optionally center graph on active file
          break;
        case 'analysisLog':
          addLog(message.message);
          break;
        case 'analysisCompleted':
          setIsAnalyzing(false);
          break;
      }
    };

    window.addEventListener('message', handleMessage);
    requestData(); // fetch on mount

    return () => {
      window.removeEventListener('message', handleMessage);
    };
  }, [setData]);

  if (!data) {
    return (
      <div className="h-screen w-full flex bg-background text-foreground overflow-hidden">
        <div className="flex-1 flex items-center justify-center">
          Loading architecture model...
        </div>
        <div className="w-1/3 min-w-[300px]">
          <AnalysisRunner />
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen w-full bg-background text-foreground overflow-hidden">
      <div className="flex flex-col flex-1 min-w-0">
        <div className="h-16 flex-none border-b border-border">
          <RiskSummary />
        </div>
        <div className="flex-1 min-h-0">
          <Graph />
        </div>
        <div className="h-64 flex-none flex border-t border-border">
          <div className="w-1/2 border-r border-border overflow-y-auto">
            <Hotspots />
          </div>
          <div className="w-1/2 overflow-y-auto">
            <Insights />
          </div>
        </div>
      </div>
      <div className="w-1/3 min-w-[300px] border-l border-border">
        <AnalysisRunner />
      </div>
    </div>
  );
}

export default App;
