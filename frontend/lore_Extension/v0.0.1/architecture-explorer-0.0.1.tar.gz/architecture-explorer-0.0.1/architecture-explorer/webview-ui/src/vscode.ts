export const vscode = acquireVsCodeApi();

export function openFile(path: string) {
  vscode.postMessage({ type: 'openFile', path });
}

export function requestData() {
  vscode.postMessage({ type: 'requestData' });
}

export function runAnalysis() {
  vscode.postMessage({ type: 'runAnalysis' });
}

// Ensure acquireVsCodeApi works in standard browser during dev by mocking
function acquireVsCodeApi() {
  if (typeof (window as any).acquireVsCodeApi === 'function') {
    return (window as any).acquireVsCodeApi();
  }
  return {
    postMessage: (message: any) => console.log('Mock VS Code Post Message:', message),
    getState: () => null,
    setState: (state: any) => console.log('Mock VS Code Set State:', state),
  };
}
