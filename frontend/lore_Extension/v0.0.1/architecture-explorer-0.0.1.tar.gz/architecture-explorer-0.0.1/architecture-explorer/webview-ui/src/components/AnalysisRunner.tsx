import React, { useEffect, useRef } from 'react';
import { useStore } from '../store';
import { runAnalysis } from '../vscode';

const AnalysisRunner: React.FC = () => {
  const isAnalyzing = useStore((state) => state.isAnalyzing);
  const logs = useStore((state) => state.logs);
  const setIsAnalyzing = useStore((state) => state.setIsAnalyzing);
  const clearLogs = useStore((state) => state.clearLogs);
  
  const logsEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    logsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const handleRun = () => {
    clearLogs();
    setIsAnalyzing(true);
    runAnalysis();
  };

  return (
    <div className="flex flex-col h-full bg-background border-l border-border p-4">
      <div className="flex items-center justify-between mb-4 flex-none">
        <h2 className="text-lg font-bold">Analysis Runner</h2>
        <button
          onClick={handleRun}
          disabled={isAnalyzing}
          className={`px-4 py-2 rounded font-medium ${
            isAnalyzing
              ? 'bg-muted text-muted-foreground cursor-not-allowed'
              : 'bg-primary text-primary-foreground hover:bg-primary/90'
          }`}
        >
          {isAnalyzing ? 'Analyzing...' : 'Run Analysis'}
        </button>
      </div>

      <div className="flex-1 min-h-0 bg-muted/50 rounded-md p-2 overflow-y-auto font-mono text-sm">
        {logs.length === 0 ? (
          <div className="text-muted-foreground italic h-full flex items-center justify-center">
            Click 'Run Analysis' to start.
          </div>
        ) : (
          logs.map((log, index) => (
            <div key={index} className="whitespace-pre-wrap break-words mb-1">
              {log}
            </div>
          ))
        )}
        <div ref={logsEndRef} />
      </div>
    </div>
  );
};

export default AnalysisRunner;
