/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        background: 'var(--vscode-editor-background)',
        foreground: 'var(--vscode-editor-foreground)',
        border: 'var(--vscode-panel-border)',
        primary: 'var(--vscode-button-background)',
        'primary-hover': 'var(--vscode-button-hoverBackground)',
        panel: 'var(--vscode-editorWidget-background)',
      }
    },
  },
  plugins: [],
}
